export type NoticeVariant = 'info' | 'error' | 'success' | 'warning';
