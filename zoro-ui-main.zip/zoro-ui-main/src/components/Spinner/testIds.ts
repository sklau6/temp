const TEST_IDS = {
  spinner: 'spinner',
};

export default TEST_IDS;
