import { BREAKPOINTS } from 'theme/MuiThemeProvider/muiTheme';

export type Breakpoint = keyof typeof BREAKPOINTS.values;
