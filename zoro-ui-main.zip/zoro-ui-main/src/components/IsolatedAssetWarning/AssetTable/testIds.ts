export default {
  assetTable: 'isolated-asset-warning-asset-table',
};
