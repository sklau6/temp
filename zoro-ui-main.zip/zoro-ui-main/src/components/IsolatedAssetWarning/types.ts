export type WarningType = 'borrow' | 'supply';
