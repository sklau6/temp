import { css } from '@emotion/react';

export const useStyles = () => ({
  container: css`
    display: inline-flex;
  `,
  icon: css`
    cursor: help;
  `,
});
