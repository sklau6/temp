const PLACEHOLDER_KEY = '-';

export default PLACEHOLDER_KEY;
