// Specific to the Compound protocol (see https://compound.finance/docs)
export const COMPOUND_DECIMALS = 18;
export const COMPOUND_MANTISSA = 1e18;
