export const DAYS_PER_YEAR = 365;
