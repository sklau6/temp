import { BLOCK_TIME_MS } from './zk';

// export const DEFAULT_REFETCH_INTERVAL_MS = BLOCK_TIME_MS * 3; // every 3 blocks (9 seconds)
export const DEFAULT_REFETCH_INTERVAL_MS = BLOCK_TIME_MS * 100; // every 100 blocks (300 seconds)
