export const ZORO_SUBSTACK_URL = "https://zoroprotocol.substack.com";
export const ZORO_DISCORD_URL = "https://discord.gg/H7uSDgtUvw";
export const ZORO_TWITTER_URL = "https://twitter.com/ZoroProtocol";
export const ZORO_GITHUB_URL = "https://github.com/zoro-protocol";
export const ZORO_TELEGRAM_URL = "https://t.me/zoroprotocol";
export const ZORO_GITBOOK_URL = "https://docs.zoroprotocol.com";
export const ZORO_LIQUIDATOR_URL = "https://liquidations.zoroprotocol.com";
